// Create WhatsApp button dynamically
document.addEventListener("DOMContentLoaded", function () {
    let whatsappBtn = document.createElement("a");
    whatsappBtn.href = "https://wa.me/919876543210"; // Replace with your WhatsApp number
    whatsappBtn.target = "_blank";
    whatsappBtn.classList.add("whatsapp-float");

    let img = document.createElement("img");
    img.src = "https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg";
    img.alt = "WhatsApp";
    img.width = 50;

    whatsappBtn.appendChild(img);
    document.body.appendChild(whatsappBtn);
});
